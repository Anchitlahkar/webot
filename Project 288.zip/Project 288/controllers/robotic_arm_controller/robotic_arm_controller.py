from controller import Robot
from controller import Keyboard

bot = Robot()
kb = Keyboard()

# create unique identifier for each device
mA = bot.getDevice("A motor")
mB = bot.getDevice("B motor")
mC = bot.getDevice("C motor")
mD = bot.getDevice("D motor")
mE = bot.getDevice("E motor")
mF = bot.getDevice("F motor")

timestep = 64
kb.enable(timestep)

mA_pos = 0
mB_pos = 0
mC_pos = 0
mD_pos = 0
mE_pos = 0
mF_pos = 0


# - perform simulation steps until Webots is stopping the controller
while bot.step(timestep) != -1:
    kp = kb.getKey()   

    # write code to move the joints with keyboard
    if kp == 49:
        mA_pos +=0.01
    elif kp == 50:
        mA_pos -= 0.01

    elif kp == 51:
        mB_pos +=0.01
    elif kp == 52:
        mB_pos -= 0.01

    elif kp == 53:
        mC_pos +=0.01
    elif kp == 54:
        mC_pos -= 0.01

    elif kp == 55:
        mD_pos +=0.01
    elif kp == 56:
        mD_pos -= 0.01

    elif kp == 57:
        mE_pos +=0.01
    elif kp == 48:
        mE_pos -= 0.01

    elif kp == 81:
        mF_pos +=0.01
    elif kp == 87:
        mF_pos -= 0.01

    
        
    mA.setPosition(mA_pos)
    mB.setPosition(mB_pos)
    mC.setPosition(mC_pos)
    mD.setPosition(mD_pos)
    mE.setPosition(mE_pos)
    mF.setPosition(mF_pos)