from controller import Robot, Keyboard, Motion

robot = Robot()

keyboard = Keyboard()

wave = Motion('D:/Project 295/motions/wave.motion')


timestep = int(robot.getBasicTimeStep())

while robot.step(timestep) != -1:
    
    key = keyboard.getKey()

    if key == Keyboard.UP:
        wave.play()